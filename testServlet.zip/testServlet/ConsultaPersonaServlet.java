package testServlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


@WebServlet("/testServlet/consultaPersona")
public class ConsultaPersonaServlet extends HttpServlet{
	

	public void doGet(HttpServletRequest request,
	HttpServletResponse response)
	throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<HEAD><TITLE> Query Result</TITLE></HEAD>");
		out.println("<BODY>");
		String persontype = request.getParameter("tipoPersona");
		System.out.println(persontype);
		
		if(persontype.equals("estudiante")) 
		{
			
			System.out.println("Selección estudiante");
		String number = request.getParameter("nombre");
		out.println("<table BORDER COLS=3>");
		out.println(" <tr> <td>ID</td> <td>Nombre </td>" +
				" <td>Apellido</td> </tr>");
		String ID = "n.a.";
		String nombre = "n.a.";
		String apellido = "n.a.";
		
	    	
	    //Intenta establecer conexi�n"nombres"
	    //System.out.println("Estableciendo conexión...");
	    try (Connection conexion = DriverManager.getConnection("jdbc:postgresql://localhost:5432/basi_taller4", "postgres", "postgres")) {	 
	            
	    	System.out.println("Conexion con la base de datos establecida (PostgreSQL)");
	        Statement statement = conexion.createStatement();
	            
	            
	        //Consulta parametrizada
	        String atributos = "*";  
	        String relacion = "public.estudiante";
	        String condicion = "nombres like "; 
	        ResultSet resultSet = statement.executeQuery("select "+atributos+"  from "+relacion+ " where "+condicion+"'"+number+"%'"+";");
	        
	        while(resultSet.next()) {
	        	nombre = resultSet.getString("nombres");
	        	apellido = resultSet.getString("apellidos");
	        	ID = resultSet.getString("id");
	        	
	    		out.println("<tr> <td>" + ID + "</td>" +
	    				"<td>" + nombre + "</td>" +
	    				"<td>" + apellido + "</td> </tr>");	        	
	        }
	        
	            	            
	        conexion.close();            
	            
	    } catch (SQLException e) {
	        System.out.println("Conexión fallida");
	        e.printStackTrace();
	    }
	    
	    
		
		
		
		}else{//IF
			System.out.println("Selección instructor");
			String number = request.getParameter("nombre");
			out.println("<table BORDER COLS=3>");
			out.println(" <tr> <td>ID</td> <td>Nombre </td>" +
					" <td>Apellido</td> <td>Salario</td> </tr>");
			String ID = "n.a.";
			String nombre = "n.a.";
			String apellido = "n.a.";
			String salario = "n.a.";
			
		    	
		    //Intenta establecer conexi�n"nombres"
		    //System.out.println("Estableciendo conexión...");
		    try (Connection conexion = DriverManager.getConnection("jdbc:postgresql://localhost:5432/basi_taller4", "postgres", "postgres")) {	 
		            
		    	System.out.println("Conexion con la base de datos establecida (PostgreSQL)");
		        Statement statement = conexion.createStatement();
		            
		            
		        //Consulta parametrizada
		        String atributos = "*";  
		        String relacion = "public.instructor";
		        String condicion = "nombres like "; 
		        ResultSet resultSet = statement.executeQuery("select "+atributos+"  from "+relacion+ " where "+condicion+"'"+number+"%'"+";");
		        
		        while(resultSet.next()) {
		        	nombre = resultSet.getString("nombres");
		        	apellido = resultSet.getString("apellidos");
		        	ID = resultSet.getString("inst_id");
		        	salario = resultSet.getString("salario");
		        	
		        	
					out.println("<tr> <td>" + ID + "</td>" +
							"<td>" + nombre + "</td>" +
							"<td>" + apellido + "</td> "+
							"<td>" + salario + "</td> "	+ "</tr>");
		        }
		        
		            	            
		        conexion.close();            
		            
		    } catch (SQLException e) {
		        System.out.println("Conexión fallida");
		        e.printStackTrace();
		    }
		    
		    
			

			
			
			
		}//Final else
			
		out.println("</table>");
		out.println("</BODY>");
		out.close();
	}
}


