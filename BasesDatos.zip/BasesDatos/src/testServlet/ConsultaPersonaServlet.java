package testServlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet("/testServlet/consultaPersona")
public class ConsultaPersonaServlet extends HttpServlet{

	public void doGet(HttpServletRequest request,
	HttpServletResponse response)
	throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<HEAD><TITLE> Query Result</TITLE></HEAD>");
		out.println("<BODY>");
		String persontype = request.getParameter("tipoPersona");
		String number = request.getParameter("nombre");
		out.println("<table BORDER COLS=3>");
		out.println(" <tr> <td>ID</td> <td>Nombre </td>" +
				" <td>Apellido</td> </tr>");
		String ID = "";
		String nombre = "";
		String apellido = "";
		
//		if(persontype.equals("estudiante")) {
//			ID = 8888;
//			nombre = "Juan";
//			depto = "MACC";
//		}
//		else {
//			ID = 2222;
//			nombre = "Renato";//		int ID;
//		String nombre;
//		String depto;
//		if(persontype.equals("estudiante")) {
//			ID = 8888;
//			nombre = "Juan";
//			depto = "MACC";
//		}
//		else {
//			ID = 2222;
//			nombre = "Renato";
//			depto = "MACC";
//		}
//			depto = "MACC";
//		}
	    	
	    	//Intenta establecer conexi�n
	    	//System.out.println("Estableciendo conexión...");
	        try (Connection conexion = DriverManager.getConnection("jdbc:postgresql://localhost:5432/basi_taller4", "postgres", "postgres")) {	 
	            
	            System.out.println("Conexion con la base de datos establecida (PostgreSQL)");
	            Statement statement = conexion.createStatement();
	            
	            
	           //Consulta parametrizada
	            String atributos = "*";  
	            String relacion = "public.estudiante";
	            String condicion = "nombres = "; 
	            ResultSet resultSet = statement.executeQuery("select "+atributos+"  from "+relacion+ " where "+condicion+"'"+number+"'"+";");
	            
	            nombre = resultSet.getString("nombres");
	            apellido = resultSet.getString("apellidos");
	            ID = resultSet.getString("id");
	            

	            	            
	            conexion.close();            
	            
	        } catch (SQLException e) {
	            System.out.println("Conexión fallida");
	            e.printStackTrace();
	        }
		
		out.println("<tr> <td>" + ID + "</td>" +
				"<td>" + nombre + "</td>" +
				"<td>" + apellido + "</td> </tr>");
			
		out.println("</table>");
		out.println("</BODY>");
		out.close();
	}
}